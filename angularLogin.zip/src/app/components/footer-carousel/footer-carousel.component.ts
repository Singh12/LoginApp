import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-carousel',
  templateUrl: './footer-carousel.component.html',
  styleUrls: ['./footer-carousel.component.css']
})
export class FooterCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
